// Use select2 for picking teams
//$(document).ready(function() { $("#gamePick").select2(); });
